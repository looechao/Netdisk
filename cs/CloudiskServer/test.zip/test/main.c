#include <func.h>
#include "log.h"
#include <pthread.h>


pthread_mutex_t lock;
pthread_mutexattr_t attr;


void my_lock_function(bool lock_b, void *udata) {
    

}

log_LockFn my_lock_func = my_lock_function;

void *print_message_function(void *ptr)
{
    FILE* fp = (FILE*)ptr;

    log_set_lock(my_lock_func,NULL);
    my_lock_func(true,NULL);
    log_error("qinhao !dasfdsqgrqfwqfmqmgrqeojgrioqpngrqiegiqerngrioqwnr");
    my_lock_func(false,NULL);
    return NULL;
}

void* print_message(void* ptr){
    
    FILE* fp = (FILE*)ptr;

    log_set_lock(my_lock_func,NULL);
    my_lock_func(true,NULL);
    log_info("lizhenhao !");
    my_lock_func(false,NULL);
    return NULL;
}

int main(int argc,char* argv[]){
    
   // log_set_level(LOG_INFO);
    

    FILE *fp = fopen("./sys.log","a");
    if(fp){
        log_add_fp(fp,LOG_INFO);
    }else{
        exit(1);

    }
    
    pthread_mutexattr_init(&attr);
    pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(&lock, &attr);


    log_set_lock(my_lock_func,NULL);
    my_lock_func(true,NULL);
    log_debug("server started !");
    my_lock_func(false,NULL);

    pthread_t thread1, thread2;

    int iret1 = pthread_create(&thread1, NULL, print_message_function, (void*)fp);
    int iret2 = pthread_create(&thread2, NULL, print_message, (void*)fp);

    /* 等待线程结束，回收其资源 */
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    log_set_lock(my_lock_func,NULL);
    my_lock_func(true,NULL);
    log_warn("server closed !");
    my_lock_func(false,NULL);
    fclose(fp);
    return 0;
}

